

library(tidyverse)
library(readxl)
library(dplyr)
library(writexl)
library(openxlsx)
library(xlsx)

rm(list = ls())


# Caraga de archivo CSV
enma <- read.csv("data/ENMA2023.csv")


#Convertir campos vacíos de la variable q5_descendencia en NA
enma <- enma %>%
  mutate(q5_descendencia = na_if(q5_descendencia, ""))

enma <- enma %>%
  mutate(nacionalidad_var = ifelse(nacionalidad_var == "", "Otra", nacionalidad_var))

consulta_a<-enma %>%
  filter(!is.na(q5_descendencia)) %>% 
  summarise(Total= round(sum(weightvec),0), 
            indigena_total=sum(weightvec[q5_descendencia_indigena==1]), #Calcula total de respuestas que indican tener descendencia indígena
            afro_total=sum(weightvec[q5_descendencia_afro==1]), #Calcula total de respuestas que indican tener descendencia indígena
            'Indígena'= round(indigena_total/Total*100,1), #Calcula porcentaje con descendencia indígena
            'Afrodescendiente'=round(afro_total/Total*100,1)) 
consulta_a



consulta_enma <- enma %>% 
  filter(tiempo_residencia_agrup!="") %>%
  group_by(nacionalidad_var,tiempo_residencia_agrup) %>% 
  summarise (cantidad = round(sum(weightvec_0))) %>% 
  mutate(Porcentaje=round((cantidad/sum(cantidad))*100,1)) 

consulta_enma

consulta_pivot<-consulta_enma %>% select(nacionalidad_var,tiempo_residencia_agrup,cantidad) %>%
  pivot_wider(names_from = tiempo_residencia_agrup, values_from = cantidad)

write.xlsx2(as.data.frame(consulta_pivot), "Cuadros/consultas_extra.xlsx", row.names = FALSE, sheetName ="nac_tiempo",append = TRUE)

consulta_enma <- enma %>% 
  filter(tiempo_residencia_agrup!="") %>%
  group_by(tiempo_residencia_agrup) %>% 
  summarise (cantidad = round(sum(weightvec))) %>% 
  mutate(Porcentaje=round((cantidad/sum(cantidad))*100,1)) 
consulta_enma

consulta_enma <- enma %>% 
  filter(tiempo_residencia_agrup!="") %>%
  group_by(q3_pais_nacimiento,tiempo_residencia_agrup) %>% 
  summarise (cantidad = round(sum(weightvec))) %>% 
  mutate(Porcentaje=round((cantidad/sum(cantidad))*100,1)) 

consulta_enma

consulta_pivot<-consulta_enma %>% select(q3_pais_nacimiento,tiempo_residencia_agrup,cantidad) %>%
  pivot_wider(names_from = tiempo_residencia_agrup, values_from = cantidad)

write.xlsx2(as.data.frame(consulta_pivot), "Cuadros/consultas_extra.xlsx", row.names = FALSE, sheetName ="nac_tiempo_2",append = TRUE)


consulta_enma <- enma %>% 
  filter(region_amba_agrup!="") %>%
  group_by(nacionalidad_var,region_amba_agrup) %>% 
  summarise (cantidad = round(sum(weightvec))) %>% 
  mutate(Porcentaje=round((cantidad/sum(cantidad))*100,1)) 

consulta_enma

consulta_pivot<-consulta_enma %>% select(nacionalidad_var,region_amba_agrup,cantidad) %>%
  pivot_wider(names_from = region_amba_agrup, values_from = cantidad)

write.xlsx2(as.data.frame(consulta_pivot), "Cuadros/consultas_extra.xlsx", row.names = FALSE, sheetName ="nac_region",append = TRUE)


consulta_enma <- enma %>% 
  filter(tiempo_residencia_agrup!="" & q37_salud_problemas_no!="") %>%
  group_by(tiempo_residencia_agrup,q37_salud_problemas_no) %>% 
  summarise (cantidad = round(sum(weightvec))) %>% 
  mutate(Porcentaje=round((cantidad/sum(cantidad))*100,1)) 

consulta_enma

consulta_pivot<-consulta_enma %>% select(tiempo_residencia_agrup,q37_salud_problemas_no,cantidad) %>%
  pivot_wider(names_from = tiempo_residencia_agrup, values_from = cantidad)

write.xlsx2(as.data.frame(consulta_pivot), "Cuadros/consultas_extra.xlsx", row.names = FALSE, sheetName ="salud_no2",append = TRUE)


